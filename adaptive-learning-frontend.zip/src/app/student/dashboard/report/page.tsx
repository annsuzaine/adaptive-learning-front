export default function ReportPage() {
    return (
      <div className="p-6">
        <h1 className="text-3xl font-bold text-gray-800">📊 Student Report</h1>
        <p className="text-gray-600 mt-2">View your progress and performance stats.</p>
      </div>
    );
  }
  