(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_login_page_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_login_page_tsx_36054f._.js",
  "chunks": [
    "static/chunks/node_modules_8acecd._.js",
    "static/chunks/[root of the server]__e1cdce._.js",
    "static/chunks/[next]_internal_font_google_poppins_1b47e1b8_module_d1fffc.css"
  ],
  "source": "dynamic"
});
