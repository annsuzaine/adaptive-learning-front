(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_student_login_page_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_student_login_page_tsx_36054f._.js",
  "chunks": [
    "static/chunks/node_modules_2a3b4b._.js",
    "static/chunks/[root of the server]__36494f._.js",
    "static/chunks/[next]_internal_font_google_poppins_35f2ea8d_module_ddf66d.css"
  ],
  "source": "dynamic"
});
