(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_36054f._.js",
  "chunks": [
    "static/chunks/node_modules_9ce53c._.js",
    "static/chunks/[root of the server]__b9e667._.js",
    "static/chunks/[next]_internal_font_google_poppins_3473fbc6_module_9ca81a.css"
  ],
  "source": "dynamic"
});
