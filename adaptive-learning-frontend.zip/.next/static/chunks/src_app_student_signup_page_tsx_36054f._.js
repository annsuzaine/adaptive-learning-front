(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_student_signup_page_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_student_signup_page_tsx_36054f._.js",
  "chunks": [
    "static/chunks/node_modules_7c4e47._.js",
    "static/chunks/[root of the server]__05497e._.js",
    "static/chunks/[next]_internal_font_google_poppins_35f2ea8d_module_ddf66d.css"
  ],
  "source": "dynamic"
});
